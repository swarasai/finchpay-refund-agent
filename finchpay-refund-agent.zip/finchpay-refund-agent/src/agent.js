// The same deterministic agent engine is used by the browser UI and the trace tests.
export const CHARGES = Object.freeze({ 'CH-101': { amountCents: 2500, currency: 'USD' } });
const VALID_CODE = '2468'; // A deliberately mocked secret, NOT real authentication.
const MAX_STEPS_PER_TURN = 12;

export function createSession() {
  return {
    currentRole: 'Triage',
    requestedCharge: null,
    verified: false,
    awaitingInput: 'refund_request',
    status: 'active',
    refunds: [],
    transcript: [{ sender: 'agent', text: 'Hi! I can help with a refund. Which charge would you like refunded?' }],
    trace: ['New chat: session.verified = false; currentRole = Triage'],
  };
}

export function verify_identity(code) {
  return { success: code === VALID_CODE };
}

// Authoritative safety check: even if a caller bypasses the agents, this tool
// refuses to create a refund without successful verification in this session.
export function issue_refund(session, chargeId) {
  if (!session.verified) return { success: false, error: 'IDENTITY_NOT_VERIFIED' };
  if (!Object.hasOwn(CHARGES, chargeId)) return { success: false, error: 'UNKNOWN_CHARGE' };
  if (session.refunds.some((refund) => refund.chargeId === chargeId)) {
    return { success: false, error: 'ALREADY_REFUNDED' };
  }
  const reference = `RF-${String(session.refunds.length + 1).padStart(3, '0')}`;
  session.refunds.push({ reference, chargeId, amountCents: CHARGES[chargeId].amountCents });
  return { success: true, reference };
}

function log(session, event) { session.trace.push(event); }
function reply(session, text) { session.transcript.push({ sender: 'agent', text }); log(session, `Agent replies: ${text}`); }
function finish(session) { session.status = 'ended'; session.awaitingInput = null; log(session, 'Loop ends: session ended'); }
function handoff(session, from, to) { session.currentRole = to; log(session, `${from} -> ${to}`); }

// A message is handled through a bounded loop: tool -> result -> handoff -> wait/end.
// This is the only function the chat page calls for customer messages.
export function submitChatMessage(session, input) {
  if (session.status !== 'active') return session;
  const message = String(input).trim();
  if (!message) return session;
  session.transcript.push({ sender: 'customer', text: message });
  log(session, `Customer: ${message}`);
  let steps = 0;
  let pendingInput = message;

  while (session.status === 'active') {
    steps += 1;
    if (steps > MAX_STEPS_PER_TURN) {
      log(session, `Step limit (${MAX_STEPS_PER_TURN}) exceeded`);
      reply(session, 'Something went wrong. Please start a new chat.');
      finish(session);
      break;
    }

    if (session.currentRole === 'Triage') {
      // Parse an explicit charge ID; never trust claims about verification.
      const match = pendingInput.match(/\bCH-\d+\b/i);
      const chargeId = match?.[0].toUpperCase();
      if (!chargeId || !Object.hasOwn(CHARGES, chargeId)) {
        log(session, `Triage: missing or unknown charge (${chargeId ?? 'none'})`);
        reply(session, 'Please provide a valid charge ID, such as CH-101.');
        log(session, 'Loop waits: customer refund request');
        break;
      }
      session.requestedCharge = chargeId;
      log(session, `Triage: session.requestedCharge = ${chargeId}`);
      handoff(session, 'Triage', 'Identity');
      // The next role acts without waiting for another user message.
      pendingInput = null;
      continue;
    }

    if (session.currentRole === 'Identity') {
      if (session.awaitingInput !== 'verification_code') {
        session.awaitingInput = 'verification_code';
        log(session, 'Identity: asks for verification code');
        reply(session, 'To refund CH-101, please enter your 4-digit verification code.');
        log(session, 'Loop waits: customer verification code');
        break;
      }
      log(session, 'Identity calls verify_identity(code)');
      const result = verify_identity(pendingInput ?? '');
      log(session, `verify_identity result: ${result.success ? 'success' : 'failure'}`);
      if (!result.success) {
        log(session, 'Identity: verification failed; session.verified remains false');
        reply(session, 'Verification failed. No refund was issued. Please start a new chat to try again.');
        finish(session); // Wrong code ends the session: no retry.
        break;
      }
      session.verified = true; // ONLY on success from verify_identity.
      session.awaitingInput = null;
      log(session, 'Identity: session.verified = true');
      handoff(session, 'Identity', 'Refund');
      pendingInput = null;
      continue;
    }

    if (session.currentRole === 'Refund') {
      log(session, `Refund calls issue_refund(${session.requestedCharge})`);
      const result = issue_refund(session, session.requestedCharge);
      log(session, `issue_refund result: ${result.success ? `success, reference ${result.reference}` : `failure, ${result.error}`}`);
      if (result.success) {
        reply(session, `Your $25.00 refund for ${session.requestedCharge} was issued. Reference: ${result.reference}.`);
      } else {
        reply(session, 'We could not issue the refund. No new refund was recorded.');
      }
      finish(session);
      break;
    }

    log(session, `Unknown role: ${session.currentRole}`);
    reply(session, 'Something went wrong. Please start a new chat.');
    finish(session);
    break;
  }
  return session;
}
